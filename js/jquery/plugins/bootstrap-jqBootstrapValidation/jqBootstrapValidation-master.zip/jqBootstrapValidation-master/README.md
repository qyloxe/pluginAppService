jqBootstapValidation
====================

A JQuery validation framework for bootstrap forms. 

Displays validation errors in `help-block` elements as users type.

[![Build Status](https://travis-ci.org/ReactiveRaven/jqBootstrapValidation.png?branch=master)](https://travis-ci.org/ReactiveRaven/jqBootstrapValidation)

How to use?
-----------
The documentation is [here](http://ReactiveRaven.github.com/jqBootstrapValidation).

Developers
------------------
Want to contribute? Great! Check out [CONTRIBUTING.md]




[![endorse](http://api.coderwall.com/reactiveraven/endorsecount.png)](http://coderwall.com/reactiveraven)
